''' your local settings.
    Note that if you install using setuptools, change this
    module first before running setup.py install.
'''
oauthkey = '7dkss6x9fn5v'
secret = 't5f28uhdmct7zhdr'
country = 'US'
